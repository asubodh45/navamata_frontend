import { createFileRoute, Link, useNavigate, useSearch } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight } from "lucide-react";
import { BuyStepper } from "@/components/common/BuyStepper";
import { Field } from "@/components/auth/Field";
import { matApi, ApiError, type MatMeasurementsInput } from "@/lib/api";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/mat/buy/mat-measurements")({
  component: Measurements,
  validateSearch: (search: Record<string, unknown>): { order?: string } =>
    typeof search.order === "string" ? { order: search.order } : {},
});

// M1–M12 per the concept PDF. Labels are placeholders for the real
// per-field video tutorials the client's PDF describes — swap in the
// actual tutorial copy/video links once the client provides them.
const fields: { key: keyof MatMeasurementsInput; label: string; required: boolean }[] = [
  { key: "fm1", label: "M1 — Height", required: true },
  { key: "fm2", label: "M2 — Shoulder width", required: true },
  { key: "fm3", label: "M3 — Arm span", required: true },
  { key: "fm4", label: "M4 — Torso length", required: true },
  { key: "fm5", label: "M5 — Hip width", required: true },
  { key: "fm6", label: "M6 — Inseam", required: true },
  { key: "fm7", label: "M7 — Foot length", required: true },
  { key: "fm8", label: "M8 — Stance width", required: true },
  { key: "fm9", label: "M9 — Grip reach", required: true },
  { key: "fm10", label: "M10 — Wrist to floor (optional)", required: false },
  { key: "fm11", label: "M11 — Neck to hip (optional)", required: false },
  { key: "fm12", label: "M12 — Ankle circumference (optional)", required: false },
];

function Measurements() {
  const navigate = useNavigate();
  const { order } = useSearch({ from: "/mat/buy/mat-measurements" });
  const [values, setValues] = useState<Record<string, string>>({});
  const [fline, setFline] = useState<"solid" | "border">("solid");
  const [motto, setMotto] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  function setValue(key: string, v: string) {
    setValues((prev) => ({ ...prev, [key]: v }));
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setServerError(null);

    const nextErrors: Record<string, string> = {};
    for (const f of fields) {
      const raw = values[f.key];
      if (!raw && f.required) {
        nextErrors[f.key] = "Required";
        continue;
      }
      if (raw) {
        const n = Number(raw);
        if (Number.isNaN(n) || n < (f.required ? 1 : 0) || n > 300) {
          nextErrors[f.key] = "Enter a value between 1 and 300 cm";
        }
      }
    }
    if (motto.length > 18) nextErrors.motto = "18 characters max";
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    const payload: MatMeasurementsInput & { pending_order_uuid?: string } = {
      fm1: Number(values.fm1),
      fm2: Number(values.fm2),
      fm3: Number(values.fm3),
      fm4: Number(values.fm4),
      fm5: Number(values.fm5),
      fm6: Number(values.fm6),
      fm7: Number(values.fm7),
      fm8: Number(values.fm8),
      fm9: Number(values.fm9),
      fm10: values.fm10 ? Number(values.fm10) : null,
      fm11: values.fm11 ? Number(values.fm11) : null,
      fm12: values.fm12 ? Number(values.fm12) : null,
      fline,
      motto: motto || undefined,
      pending_order_uuid: order,
    };

    setSubmitting(true);
    try {
      const res = await matApi.submitMeasurements(payload);
      navigate({ to: "/mat/buy/order-confirmation", search: { order: res.uuid } });
    } catch (err) {
      if (
        err instanceof ApiError &&
        err.status === 422 &&
        err.body &&
        typeof err.body === "object"
      ) {
        const reason = (err.body as { reason?: string }).reason;
        if (reason === "address_required") {
          navigate({ to: "/mat/buy/delivery-address" });
          return;
        }
      }
      setServerError(err instanceof ApiError ? err.message : "Couldn't save your measurements.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="pb-32">
      <BuyStepper current={3} />
      <section className="container-page grid gap-16 py-16 lg:grid-cols-[1fr_1.3fr] lg:py-20">
        <div className="flex flex-col">
          <div className="eyebrow mb-3">Step 04 · Measurements</div>
          <h1 className="font-display text-5xl leading-[1.05]">
            Twelve points, <em className="not-italic text-brand">precisely yours.</em>
          </h1>
          <p className="mt-6 max-w-sm text-sm leading-relaxed text-warm-gray">
            Nine measurements are required; the last three refine the fit further. Each has a short
            video tutorial showing exactly how to take it. All values in centimetres.
          </p>
        </div>

        <form onSubmit={onSubmit} noValidate className="space-y-10">
          <div className="grid gap-8 sm:grid-cols-2">
            {fields.map((f) => (
              <Field
                key={f.key}
                label={f.label}
                name={f.key}
                type="number"
                inputMode="decimal"
                min={f.required ? 1 : 0}
                max={300}
                value={values[f.key] ?? ""}
                onChange={(e) => setValue(f.key, e.target.value)}
                error={errors[f.key]}
                placeholder="cm"
              />
            ))}
          </div>

          <div>
            <div className="eyebrow mb-4">Alignment line</div>
            <div className="flex gap-3">
              {(["solid", "border"] as const).map((opt) => (
                <button
                  type="button"
                  key={opt}
                  onClick={() => setFline(opt)}
                  className={cn(
                    "border px-5 py-3 text-sm capitalize transition-colors",
                    fline === opt
                      ? "border-ink bg-ink text-soft-white"
                      : "border-hairline text-charcoal hover:border-charcoal",
                  )}
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>

          <Field
            label="Personal motto (optional)"
            name="motto"
            value={motto}
            onChange={(e) => setMotto(e.target.value)}
            maxLength={18}
            hint={`${motto.length}/18 characters`}
            error={errors.motto}
            placeholder="A short line for your mat"
          />

          {serverError && <p className="text-sm text-destructive">{serverError}</p>}

          <div className="flex items-center justify-between border-t hairline pt-8">
            <Link
              to="/mat/buy/mat-payment"
              className="text-xs uppercase tracking-[0.22em] text-charcoal hover:text-ink"
            >
              ← Back
            </Link>
            <button
              type="submit"
              disabled={submitting}
              className="inline-flex h-12 items-center gap-3 bg-ink px-7 text-xs uppercase tracking-[0.22em] text-soft-white hover:bg-charcoal disabled:opacity-60"
            >
              {submitting ? "Saving…" : "Continue"} <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </form>
      </section>
    </div>
  );
}
