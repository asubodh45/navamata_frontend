import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { AdminPageHeader } from "@/components/admin/AdminShell";
import { matDashboardApi, API_BASE, tokenStore, tryRefresh, ApiError } from "@/lib/api";
export const Route = createFileRoute("/admin/mat-dashboard")({
  component: MatDashboard,
});

const STATUSES = ["pending", "in_process", "completed", "shipped"] as const;

function MatDashboard() {
  const queryClient = useQueryClient();
  const [status, setStatus] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [noteDrafts, setNoteDrafts] = useState<Record<string, string>>({});
  const [busyUuid, setBusyUuid] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["admin-mat-dashboard", status, search],
    queryFn: () =>
      matDashboardApi.list({
        status: status === "all" ? undefined : status,
        search: search || undefined,
      }),
  });

  async function handleStatusChange(uuid: string, next: string) {
    setError(null);
    setBusyUuid(uuid);
    try {
      await matDashboardApi.updateStatus(uuid, next);
      queryClient.invalidateQueries({ queryKey: ["admin-mat-dashboard"] });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Couldn't update status.");
    } finally {
      setBusyUuid(null);
    }
  }

  async function handleAddNote(uuid: string) {
    const note = noteDrafts[uuid]?.trim();
    if (!note) return;
    setError(null);
    setBusyUuid(uuid);
    try {
      await matDashboardApi.addNote(uuid, note);
      setNoteDrafts((prev) => ({ ...prev, [uuid]: "" }));
      queryClient.invalidateQueries({ queryKey: ["admin-mat-dashboard"] });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Couldn't save note.");
    } finally {
      setBusyUuid(null);
    }
  }

  async function downloadSvg(uuid: string, _retried = false) {
    const token = tokenStore.getAccessToken();

    try {
      const res = await fetch(`${API_BASE}/mat/dashboard/${uuid}/svg`, {
        headers: {
          Accept: "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      });

      // Token expired/invalid — refresh once and retry, same as the shared request() client.
      if (res.status === 401 && !_retried) {
        const refreshed = await tryRefresh();
        if (refreshed) {
          return downloadSvg(uuid, true);
        }
        tokenStore.clear();
        setError("Your session expired — please log in again.");
        return;
      }

      if (!res.ok) throw new Error("Download failed");

      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `navamata_mat_${uuid.slice(0, 8)}.ai`;
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      setError("Couldn't download the layout file.");
    }
  }

  const orders = data?.data ?? [];

  return (
    <div>
      <AdminPageHeader title="Mat production" />
      <div className="p-8">
        <div className="mb-6 flex flex-wrap gap-3">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name, email, order ref…"
            className="h-10 w-64 border hairline bg-soft-white px-3 text-sm"
          />
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="h-10 border hairline bg-soft-white px-3 text-sm capitalize"
          >
            <option value="all">All statuses</option>
            {STATUSES.map((s) => (
              <option key={s} value={s}>
                {s.replace("_", " ")}
              </option>
            ))}
          </select>
        </div>

        {error && <p className="mb-4 text-sm text-destructive">{error}</p>}

        {isLoading ? (
          <p className="text-sm text-warm-gray">Loading…</p>
        ) : orders.length === 0 ? (
          <p className="text-sm text-warm-gray">No orders match.</p>
        ) : (
          <div className="space-y-4">
            {orders.map((o) => (
              <div key={o.uuid} className="border hairline bg-soft-white p-5">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="font-display text-lg text-ink">{o.user?.name ?? "—"}</div>
                    <div className="text-xs text-warm-gray">
                      {o.user?.email} · {o.uuid.slice(0, 8).toUpperCase()}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <select
                      value={o.status}
                      disabled={busyUuid === o.uuid}
                      onChange={(e) => handleStatusChange(o.uuid, e.target.value)}
                      className="h-9 border hairline bg-background px-2 text-xs uppercase tracking-[0.12em] capitalize"
                    >
                      {STATUSES.map((s) => (
                        <option key={s} value={s}>
                          {s.replace("_", " ")}
                        </option>
                      ))}
                    </select>
                    <button
                      onClick={() => downloadSvg(o.uuid)}
                      className="h-9 border hairline px-3 text-xs uppercase tracking-[0.12em] text-charcoal hover:border-ink hover:text-ink"
                    >
                      Download layout
                    </button>
                  </div>
                </div>

                {o.notes && (
                  <pre className="mt-4 whitespace-pre-wrap border-t hairline pt-4 font-sans text-xs text-warm-gray">
                    {o.notes}
                  </pre>
                )}

                <div className="mt-4 flex gap-2">
                  <input
                    value={noteDrafts[o.uuid] ?? ""}
                    onChange={(e) =>
                      setNoteDrafts((prev) => ({ ...prev, [o.uuid]: e.target.value }))
                    }
                    placeholder="Add an internal note…"
                    className="h-9 flex-1 border hairline bg-background px-3 text-xs"
                  />
                  <button
                    onClick={() => handleAddNote(o.uuid)}
                    disabled={busyUuid === o.uuid || !noteDrafts[o.uuid]?.trim()}
                    className="h-9 border border-ink bg-ink px-4 text-xs uppercase tracking-[0.12em] text-soft-white disabled:opacity-40"
                  >
                    Save note
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
