import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { catalogApi, videoCheckoutApi, ApiError } from "@/lib/api";
import { apiVideoToVideoItem } from "@/lib/catalogAdapters";
import { VideoCard } from "@/components/cards/VideoCard";
import { SectionHeader } from "@/components/common/SectionHeader";
import { useAuth } from "@/contexts/AuthContext";

export const Route = createFileRoute("/mat/practice")({
  component: PracticePage,
  validateSearch: (
    search: Record<string, unknown>,
  ): { purchase?: "success" | "cancelled"; session_id?: string } => {
    const result: { purchase?: "success" | "cancelled"; session_id?: string } = {};
    if (search.purchase === "success" || search.purchase === "cancelled")
      result.purchase = search.purchase;
    if (typeof search.session_id === "string") result.session_id = search.session_id;
    return result;
  },
});

/**
 * StripeController::createVideoCheckout's success_url lands here directly
 * (with ?purchase=success&session_id=...) rather than a dedicated route —
 * so purchase confirmation happens inline on this page.
 */
function usePurchaseConfirmation() {
  const { purchase, session_id } = Route.useSearch();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [banner, setBanner] = useState<{
    kind: "success" | "error" | "cancelled";
    text: string;
  } | null>(null);
  const attempts = useRef(0);

  useEffect(() => {
    if (purchase === "cancelled") {
      setBanner({ kind: "cancelled", text: "Checkout was cancelled — nothing was charged." });
      navigate({ to: "/mat/practice", search: {}, replace: true });
      return;
    }

    if (purchase === "success" && session_id) {
      let cancelled = false;

      async function poll() {
        try {
          const res = await videoCheckoutApi.confirmCheckout(session_id!);
          if (cancelled) return;

          if (!res.paid) {
            setBanner({ kind: "error", text: "That payment did not complete." });
            return;
          }
          if (!res.purchase_recorded && attempts.current < 6) {
            attempts.current += 1;
            setTimeout(poll, 1500);
            return;
          }
          setBanner({ kind: "success", text: "Purchase complete — it's in your library below." });
          queryClient.invalidateQueries({ queryKey: ["practice-library"] });
        } catch (err) {
          if (cancelled) return;
          setBanner({
            kind: "error",
            text: err instanceof ApiError ? err.message : "Couldn't confirm that purchase.",
          });
        }
      }

      poll();
      navigate({ to: "/mat/practice", search: {}, replace: true });
      return () => {
        cancelled = true;
      };
    }
  }, [purchase, session_id]); // eslint-disable-line react-hooks/exhaustive-deps

  return banner;
}

function PracticePage() {
  const { isAuthenticated, isLoading: authLoading, role } = useAuth();
  const banner = usePurchaseConfirmation();

  const { data, isLoading, error } = useQuery({
    queryKey: ["practice-library"],
    queryFn: () => catalogApi.practiceLibrary(),
    enabled: isAuthenticated,
    retry: false,
  });

  const items = (data?.data ?? []).map(apiVideoToVideoItem);
  const matRequired = error instanceof ApiError && error.status === 403;

  return (
    <div className="pb-32">
      {banner && (
        <div
          className={`border-b hairline px-8 py-4 text-center text-sm ${
            banner.kind === "success"
              ? "bg-brand/10 text-ink"
              : banner.kind === "cancelled"
                ? "bg-muted text-charcoal"
                : "bg-destructive/10 text-destructive"
          }`}
        >
          {banner.text}
        </div>
      )}
      <section className="relative overflow-hidden bg-ink text-soft-white">
        <img
          src="https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?auto=format&fit=crop&w=2000&q=80"
          alt=""
          aria-hidden
          className="absolute inset-0 h-full w-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-ink/70 via-ink/60 to-ink" />
        <div className="container-page relative z-10 py-24 md:py-32">
          <div className="eyebrow mb-8 text-soft-white/60">Your practice</div>
          <h1 className="max-w-4xl font-display font-bold text-[clamp(3.5rem,9vw,8rem)] leading-[0.9] tracking-[-0.035em]">
            A library
            <br />
            <em className="not-italic text-brand">kept close.</em>
          </h1>
          <p className="mt-10 max-w-xl text-lg leading-relaxed text-soft-white/75">
            Every free premium session, and everything you've purchased — held in one place.
          </p>
        </div>
      </section>

      {!authLoading && !isAuthenticated && (
        <section className="container-page py-24 text-center">
          <p className="font-display text-3xl text-ink">Sign in to see your practice library.</p>
          <Link
            to="/signin"
            className="mt-8 inline-flex h-12 items-center bg-ink px-10 text-xs uppercase tracking-[0.22em] text-soft-white hover:bg-charcoal"
          >
            Sign in
          </Link>
        </section>
      )}

      {isAuthenticated && matRequired && (
        <section className="container-page py-24 text-center">
          <p className="font-display text-3xl text-ink">The practice library is for mat owners.</p>
          <p className="mt-4 text-sm text-warm-gray">
            Buy your Navamata mat to unlock the full library.
          </p>
          <Link
            to="/mat/buy"
            className="mt-8 inline-flex h-12 items-center bg-ink px-10 text-xs uppercase tracking-[0.22em] text-soft-white hover:bg-charcoal"
          >
            Acquire the mat
          </Link>
        </section>
      )}

      {isAuthenticated && role === "practitioner" && (
        <section className="container-page py-20">
          <SectionHeader
            eyebrow="Your library"
            title="Free premium & purchased sessions."
            className="mb-12"
          />
          {isLoading ? (
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="aspect-[16/10] animate-pulse bg-muted" />
              ))}
            </div>
          ) : items.length === 0 ? (
            <div className="border hairline px-10 py-32 text-center">
              <p className="font-display text-2xl">
                Nothing here yet — browse the disciplines to begin.
              </p>
              <Link
                to="/mat/explore"
                className="mt-6 inline-flex items-center gap-2 text-xs uppercase tracking-[0.22em] text-ink hover:underline"
              >
                Browse the disciplines
              </Link>
            </div>
          ) : (
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              {items.map((v) => (
                <VideoCard key={v.id} video={v} />
              ))}
            </div>
          )}
        </section>
      )}
    </div>
  );
}
