import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight } from "lucide-react";
import { BuyStepper } from "@/components/common/BuyStepper";
import { Field, TextAreaField } from "@/components/auth/Field";
import { matApi, ApiError } from "@/lib/api";

export const Route = createFileRoute("/mat/buy/delivery-address")({
  component: DeliveryAddress,
});

function DeliveryAddress() {
  const navigate = useNavigate();
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);

    const required = {
      name: "name",
      line1: "address1",
      city: "city",
      country: "country",
      postal: "postal",
    };
    const e2: Record<string, string> = {};
    for (const [, field] of Object.entries(required)) {
      if (!String(data.get(field) ?? "").trim()) e2[field] = "Required";
    }
    setErrors(e2);
    if (Object.keys(e2).length > 0) return;

    setSubmitting(true);
    try {
      const res = await matApi.saveAddress({
        name: String(data.get("name")),
        line1: String(data.get("address1")),
        line2: String(data.get("address2") || "") || null,
        city: String(data.get("city")),
        country: String(data.get("country")),
        postal: String(data.get("postal")),
      });
      // next_step is "payment" for a fresh draft, or "measurements" if this
      // user already has a paid order waiting on measurements.
      navigate({
        to: res.next_step === "measurements" ? "/mat/buy/mat-measurements" : "/mat/buy/mat-payment",
      });
    } catch (err) {
      setErrors({ name: err instanceof ApiError ? err.message : "Couldn't save your address." });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="pb-32">
      <BuyStepper current={1} />
      <section className="container-page grid gap-16 py-16 lg:grid-cols-[1fr_1.2fr] lg:py-20">
        <div>
          <div className="eyebrow mb-3">Step 02 · Delivery</div>
          <h1 className="font-display text-5xl leading-[1.05]">
            Where shall it <em className="not-italic text-brand">arrive?</em>
          </h1>
          <p className="mt-6 max-w-sm text-sm leading-relaxed text-warm-gray">
            Each mat is hand-finished and delivered within ten working days, signed for at the door.
            Carbon-neutral shipping is included.
          </p>
        </div>

        <form onSubmit={onSubmit} className="space-y-8" noValidate>
          <Field label="Full name" name="name" placeholder="Anaïs Laurent" error={errors.name} />
          <Field
            label="Street address"
            name="address1"
            placeholder="14 Rue de Sévigné"
            error={errors.address1}
          />
          <Field label="Apartment, suite (optional)" name="address2" />
          <div className="grid gap-8 md:grid-cols-2">
            <Field label="City" name="city" placeholder="Paris" error={errors.city} />
            <Field label="Postal code" name="postal" placeholder="75004" error={errors.postal} />
          </div>
          <Field label="Country" name="country" placeholder="France" error={errors.country} />
          <TextAreaField label="Delivery notes (optional)" name="notes" />

          <div className="flex items-center justify-between border-t hairline pt-8">
            <Link
              to="/mat/buy"
              className="text-xs uppercase tracking-[0.22em] text-charcoal hover:text-ink"
            >
              ← Back
            </Link>
            <button
              type="submit"
              disabled={submitting}
              className="inline-flex h-12 items-center gap-3 bg-ink px-7 text-xs uppercase tracking-[0.22em] text-soft-white hover:bg-charcoal disabled:opacity-60"
            >
              {submitting ? "Saving…" : "Continue"} <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </form>
      </section>
    </div>
  );
}
